﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class ShortcutControl : UserControl
    {
        public string Path { get; private set; }
        public string Caption { get; private set; }

        public ShortcutControl()
        {
            InitializeComponent();
        }
        public void Init(string path, string caption)
        {
            this.Path = path;
            this.Caption = caption;

            pictureBox.BackgroundImage = getImage(path);
            label.Text = caption;
        }

        private Image getImage(string path)
        {
            //var help = new IconHelpOld(path);
            var icon = IconHelp.getHighestIcon(path, 1);
            return icon != null ? icon.ToBitmap() : null;
        }
    }
}
