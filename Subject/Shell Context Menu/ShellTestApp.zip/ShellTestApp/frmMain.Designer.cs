namespace ShellTestApp
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.imgMain = new System.Windows.Forms.ImageList(this.components);
            this.treeMain = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // imgMain
            // 
            this.imgMain.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgMain.ImageStream")));
            this.imgMain.TransparentColor = System.Drawing.Color.Transparent;
            this.imgMain.Images.SetKeyName(0, "RemovableDrive.png");
            this.imgMain.Images.SetKeyName(1, "CDRom.png");
            this.imgMain.Images.SetKeyName(2, "Desktop.png");
            this.imgMain.Images.SetKeyName(3, "Drive.png");
            this.imgMain.Images.SetKeyName(4, "MyComputer.png");
            this.imgMain.Images.SetKeyName(5, "NetworkDrive.png");
            this.imgMain.Images.SetKeyName(6, "Folder.png");
            // 
            // treeMain
            // 
            this.treeMain.AllowDrop = true;
            this.treeMain.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeMain.ImageIndex = 6;
            this.treeMain.ImageList = this.imgMain;
            this.treeMain.Location = new System.Drawing.Point(0, 0);
            this.treeMain.Name = "treeMain";
            this.treeMain.SelectedImageIndex = 0;
            this.treeMain.Size = new System.Drawing.Size(403, 457);
            this.treeMain.TabIndex = 3;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 457);
            this.Controls.Add(this.treeMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "File Explorer";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imgMain;
        private System.Windows.Forms.TreeView treeMain;
    }
}

