using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ShellTestApp
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();


            TreeNode rootDesktop = new TreeNode("Desktop", 2, 2);
            this.treeMain.Nodes.Add(rootDesktop);
            rootDesktop.Name = "Desktop";
            rootDesktop.Nodes.Add("");
            TreeNode myComputer = new TreeNode("My Computer", 4, 4);
            myComputer.Name = "My Computer";
            this.treeMain.Nodes.Add(myComputer);
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                TreeNode driveNode = new TreeNode(drive.Name);
                driveNode.Name = drive.Name;
                switch (drive.DriveType)
                {
                    case DriveType.CDRom:
                        driveNode.SelectedImageIndex = 1;
                        driveNode.ImageIndex = 1;
                        break;
                    case DriveType.Network:
                        driveNode.SelectedImageIndex = 5;
                        driveNode.ImageIndex = 5;
                        break;
                    case DriveType.Removable:
                        driveNode.SelectedImageIndex = 0;
                        driveNode.ImageIndex = 0;
                        break;
                    default:
                        driveNode.SelectedImageIndex = 3;
                        driveNode.ImageIndex = 3;
                        break;
                }
                driveNode.Nodes.Add("");
                myComputer.Nodes.Add(driveNode);
            }

            this.treeMain.BeforeExpand += new TreeViewCancelEventHandler(treeMain_BeforeExpand);
            this.treeMain.MouseDown += new MouseEventHandler(treeMain_MouseDown);
        }

        void treeMain_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.treeMain.SelectedNode = this.treeMain.GetNodeAt(e.X, e.Y);
                if (this.treeMain.SelectedNode.Tag != null)
                {
                    ShellContextMenu ctxMnu = new ShellContextMenu();
                    FileInfo[] arrFI = new FileInfo[1];
                    arrFI[0] = new FileInfo(this.treeMain.SelectedNode.Tag.ToString());
                    ctxMnu.ShowContextMenu(arrFI, this.PointToScreen(new Point(e.X, e.Y)));
                }
                else
                {
                    ShellContextMenu ctxMnu = new ShellContextMenu();
                    DirectoryInfo[] dir = new DirectoryInfo[1];
                    dir[0] = new DirectoryInfo(GetFolderPath(this.treeMain.SelectedNode));
                    ctxMnu.ShowContextMenu(dir, this.PointToScreen(new Point(e.X, e.Y)));
                }
            }
        }

        private void treeMain_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            if (e.Node.Text != "My Computer")
            {
                this.EnumerateDirectory(e.Node);
            }
        }

        private void EnumerateDirectory(TreeNode parentNode)
        {
            DirectoryInfo dirInfo;
            string path = GetFolderPath(parentNode);
            parentNode.Nodes.Clear();

            dirInfo = new DirectoryInfo(path);
            DirectoryInfo[] dirs = dirInfo.GetDirectories();
            Array.Sort(dirs, new DirectorySorter());
            foreach (DirectoryInfo dirI in dirs)
            {
                TreeNode node = new TreeNode(dirI.Name, 6, 6);
                node.Name = dirI.Name;
                node.Nodes.Add("");
                parentNode.Nodes.Add(node);
            }

            FileInfo[] files = dirInfo.GetFiles();
            Array.Sort(files, new FileSorter());
            foreach (FileInfo file in files)
            {
                TreeNode node = new TreeNode(file.Name, 6, 6);
                node.Name = file.Name;

                this.imgMain.Images.Add(GetFileIcon(file.FullName, false));

                int imgIndex = this.imgMain.Images.Count - 1;
                node.Tag = file.FullName;
                node.ImageIndex = imgIndex;
                node.SelectedImageIndex = imgIndex;
                parentNode.Nodes.Add(node);
            }
        }

        private static string GetFolderPath(TreeNode parentNode)
        {
            string path = "";
            string[] pathSplit = parentNode.FullPath.Split('\\');
            if (pathSplit[0] == "Desktop")
            {
                path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\";
                for (int a = 1; a < pathSplit.Length; a++)
                {
                    if (pathSplit[a].Trim() != string.Empty)
                    {
                        path += pathSplit[a] + "\\";
                    }
                }
            }
            else
            {
                for (int a = 1; a < pathSplit.Length; a++)
                {
                    if (pathSplit[a].Trim() != string.Empty)
                    {
                        path += pathSplit[a] + "\\";
                    }
                }

            }
            return path;
        }

        /// <summary>
        /// Gets the Shell Icon for the given file...
        /// </summary>
        /// <param name="name">Path to file.</param>
        /// <param name="linkOverlay">Link Overlay</param>
        /// <returns>Icon</returns>
        public static System.Drawing.Icon GetFileIcon(string name, bool linkOverlay)
        {
            Shell32.SHFILEINFO shfi = new Shell32.SHFILEINFO();
            uint flags = Shell32.SHGFI_ICON | Shell32.SHGFI_USEFILEATTRIBUTES;

            if (linkOverlay) flags += Shell32.SHGFI_LINKOVERLAY;
            flags += Shell32.SHGFI_SMALLICON; // include the small icon flag

            Shell32.SHGetFileInfo(name,
                Shell32.FILE_ATTRIBUTE_NORMAL,
                ref shfi,
                (uint)System.Runtime.InteropServices.Marshal.SizeOf(shfi),
                flags);


            // Copy (clone) the returned icon to a new object, thus allowing us 
            // to call DestroyIcon immediately
            System.Drawing.Icon icon = (System.Drawing.Icon)
                                 System.Drawing.Icon.FromHandle(shfi.hIcon).Clone();
            User32.DestroyIcon(shfi.hIcon); // Cleanup
            return icon;
        }
    }
}