using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CoreAudioSample
{
    public class Class1
    {
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.Run(new Form1());
        }
    }
}
        